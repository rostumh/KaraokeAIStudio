# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

project = Path(SPECPATH).parent
hidden = [
    "PySide6.QtMultimedia",
    "PySide6.QtMultimediaWidgets",
    "platformdirs",
    "packaging.version",
    "faster_whisper",
    "faster_whisper.transcribe",
    "faster_whisper.audio",
    "faster_whisper.vad",
    "ctranslate2",
    "av",
    "tokenizers",
    "huggingface_hub",
    "onnxruntime",
]

ai_datas = []
ai_binaries = []
for package in ("demucs", "torch", "torchaudio", "soundfile", "faster_whisper", "ctranslate2", "av", "tokenizers", "huggingface_hub", "onnxruntime"):

    package_datas, package_binaries, package_hidden = collect_all(package)
    ai_datas += package_datas
    ai_binaries += package_binaries
    hidden += package_hidden

a = Analysis(
    [str(project / "main.py"), str(project / "packaging" / "demucs_runner.py")],
    pathex=[str(project)],
    binaries=ai_binaries,
    datas=ai_datas + [
        (str(project / "config" / "default.json"), "config"),
        (str(project / "docs"), "docs"),
        (str(project / "models" / "model-catalog.json"), "models"),
    ],
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[str(project / "packaging" / "pyinstaller" / "runtime_hook.py")],
    excludes=["tkinter", "pytest", "ruff", "mypy"],
    noarchive=False,
)
pyz = PYZ(a.pure)
main_script = next(script for script in a.scripts if script[0] == "main")
runner_script = next(script for script in a.scripts if script[0] == "demucs_runner")
exe = EXE(
    pyz,
    [main_script],
    [],
    exclude_binaries=True,
    name="KaraokeAIStudio",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version=str(project / "packaging" / "windows_version_info.txt"),
    icon=str(project / "packaging" / "assets" / "KaraokeAIStudio.ico"),
)
runner = EXE(
    pyz,
    [runner_script],
    [],
    exclude_binaries=True,
    name="DemucsRunner",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
)
coll = COLLECT(
    exe,
    runner,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="KaraokeAIStudio",
)
