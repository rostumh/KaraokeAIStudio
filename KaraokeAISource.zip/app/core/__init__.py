"""Cross-cutting application infrastructure."""
