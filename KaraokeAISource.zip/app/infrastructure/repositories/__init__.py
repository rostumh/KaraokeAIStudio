"""Persistent repository adapters."""
