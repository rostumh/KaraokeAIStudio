"""Offline lyrics translation adapters."""
