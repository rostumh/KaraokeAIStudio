"""Persistent batch-processing infrastructure."""
