"""SQLite adapters and migrations."""
