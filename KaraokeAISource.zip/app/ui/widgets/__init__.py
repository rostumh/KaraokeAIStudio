"""Reusable presentation widgets."""
