"""Specialized item delegates."""
