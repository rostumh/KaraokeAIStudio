"""Undoable editor commands."""
