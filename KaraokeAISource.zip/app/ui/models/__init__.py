"""Qt presentation models."""
